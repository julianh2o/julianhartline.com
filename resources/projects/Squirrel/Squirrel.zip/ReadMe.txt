Read Me:

Both Modes:
e = toggle edit mode
l = open level list to load another level (remember to save first if you made changes)

Play Mode:
w, a, s, d = move character
	move along floor
	climb up and down walls
space = jump
mouse - click to shoot

Climbing:
press toward the wall to grab it, while holding toward the wall, press up and down to climb it.

Wall Jump:
while clinging to a wall, press space to jump off it

Edit Mode:
w, a, s, d = move camera
up, left, down, right = nudge selected platform
+ = save level
right click = add platform
backspace = delete selected platform
1 = turn selected platform to type "normal"
2 = turn selected platform to type "anticlimb"
3 = turn selected platform to type "antitrick"
shift = hold to select multiple platforms
x = cut selected platform
c = copy selected platform
v = paste selected platform
` (backquote) = open create menu

click and drag to move objects
click and drag near the bottom right corner to resize

to create platforms, right click
to delete platforms, click on a platform, then press backspace


TO CHANGE DEFAULT LEVEL:
Right click on the application (SDLOGL.app) and select Show Package Contents. Navigate to Contents->Resources->Levels and open the file called loadlevel.txt.
Change the contents of this file to the name level that you would like to load.
(the levels to load are in the same directory)