Read Me: Gravity

Controls:
w, a, d = thrust, and turn
1 = equip thruster 1 (normal thruster)
2 = equip thruster 1 (boost thruster)
` = reset character position
<space> = fire

-, + = soom in and out
<up>, <left>, <down>, <right> = pan camera

Shoot the enemy ships, and avoid being sucked into the planet's atmosphere

The bar on the left is your energy, this goes down as you use your thrusters.

The bar on the right is your thruster heat, as you use your thrusters this increases.