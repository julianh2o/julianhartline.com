/*
 *  Particle.h
 *  Gravity
 *
 *  Created by Julian on 9/15/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

#ifndef Particle_H
#define Particle_H

#ifdef __APPLE__
    #include <SDL.h>
    #include <GLUT/glut.h>
#else
    #include <SDL/SDL.h>
    #include <GL/glut.h>
#endif

#include "Inertial.h"
#include "Vector2D.h"
#include "Drawable.h"
#include "Updatable.h"
#include "Functions.h"

class Particle : public Inertial, public Drawable, public Updatable {
	bool dead;
	int life;
public:
	Particle(int life);
	void draw();
	void update(int delta);
	bool isDead();
	void kill();
};


#endif
