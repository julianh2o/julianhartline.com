/*
 *  Gravity.cpp
 *  Gravity
 *
 *  Created by Julian on 8/16/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// main program! most of the game play is handled here

#include "Gravity.h"

Gravity::Gravity() {
//	printf("sizeof ship: %d\n",sizeof(Ship));
//	printf("sizeof proj: %d\n",sizeof(Projectile));
//	printf("sizeof planet: %d\n",sizeof(Planet));
//	printf("sizeof vect: %d\n",sizeof(Vector2D));
	srand(time(NULL));
	k = new KeyBinding();
	v = new View(200,200);
	fullscreen = false;

	//to be relocated to a file-based read system

	//set up keybindings	
	k->bind("up",SDLK_w);
	k->bind("left",SDLK_a);
	k->bind("down",SDLK_s);
	k->bind("right",SDLK_d);
	k->bind("fire",SDLK_SPACE);
	k->bind("reset",SDLK_BACKQUOTE);
	
	k->bind("pan_up",SDLK_UP);
	k->bind("pan_left",SDLK_LEFT);
	k->bind("pan_down",SDLK_DOWN);
	k->bind("pan_right",SDLK_RIGHT);
	k->bind("menu_select",SDLK_SPACE);
	
	k->bind("zoom_out",SDLK_MINUS);
	k->bind("zoom_in",SDLK_EQUALS);
	
	k->bind("pause",SDLK_ESCAPE);

	//position planets
	planets.push_back(new Planet(400,-50,20,50));
	planets.push_back(new Planet(500,500,35,150));
//	planets.push_back(new Planet(600,350,5,30));

	//creates a set of equipment that can be equipped
	eq = new EquipmentCollection();

//	Weapon(double reloadSpeed, double firingRate, double usageDrain, double usageHeat, double heatCapacity, double coolingRate, double capacity, int ammunitionType, double ammunitionMass, double muzzleVelocity, double mass)
	PartSet * weapons = new PartSet();
	weapons->addPart(new Weapon(0, 600, 10, 10, 50, 10, 10, 0, 0, 200,1));
	weapons->addPart(new Weapon(0, 60, 1, 10, 50, 10, 10, 0, 0, 400,1));
	
	eq->setPartSet(EquipmentCollection::WEAPON,weapons);
	
//	Thruster(double thrust, double usageDrain, double usageHeat, double heatCapacity, double coolingRate, double mass);
	PartSet * thrusters = new PartSet();
	thrusters->addPart(new Thruster(50, 15, 40, 40, 20, 1));
	thrusters->addPart(new Thruster(200, 60, 100, 40, 20, 1));
	thrusters->addPart(new Thruster(200, 10, 10, 40, 20, 1));
	eq->setPartSet(EquipmentCollection::THRUSTER,thrusters);

//	Capacitor(double capacity, double overchargeLeak, double mass);
	PartSet * capacitors = new PartSet();
	capacitors->addPart(new Capacitor(100, 2, 1));
	capacitors->addPart(new Capacitor(200, 1, 3));
	eq->setPartSet(EquipmentCollection::CAPACITOR,capacitors);
	
//	Generator(double energyOutput, double emergencyOutput, double usageHeat, double heatCapacity, double coolingRate, double mass);
	PartSet * generators = new PartSet();
	generators->addPart(new Generator(5, 2, 0, 100, 3, 1));
	generators->addPart(new Generator(7, 4, 0, 100, 3, 2));
	eq->setPartSet(EquipmentCollection::GENERATOR,generators);
	
//	Radiator(double coolingRate, double emergencyRate, double energyDrain, double flashCoolingRate, double flashCoolingCapacity, double flashCoolingRecharge, double mass);
	PartSet * radiators = new PartSet();
	radiators->addPart(new Radiator(1, 5, 10, 3, 50, 30, 5, 1));
	radiators->addPart(new Radiator(2, 5, 15, 3, 50, 30, 5, 2));
	eq->setPartSet(EquipmentCollection::RADIATOR,radiators);

	ship = new Ship(200,200);
	//equip the ship with the default parts
	ship->equip(weapons->getPartAt(1));
	ship->equip(thrusters->getPartAt(0));
	ship->equip(capacitors->getPartAt(0));
	ship->equip(generators->getPartAt(0));
	ship->equip(radiators->getPartAt(0));

	menu = new EquipMenu(eq, ship);
	
	// create enemies
	for (int i=0; i<9; i++) {
		// equip enemy ships with default parts
		Ship * enemy = new Ship(rand()%600,rand()%600);
		enemy->equip(thrusters->getPartAt(2));
		enemy->equip(capacitors->getPartAt(0));
		enemy->equip(generators->getPartAt(0));
		enemy->equip(radiators->getPartAt(0));
		enemies.push_back(enemy);
	}

	//we start our ship with a velocity perpendicular to planet 0, simply to avoid being
	// instantly sucked into the planet
	Vector2D a = planets[0]->getPos();
	Vector2D diff = *ship - a;
	double rad = diff.getMagnitude();
	double mass = planets[0]->getMass();
	double mu = mass*GRAV_G;
	double v = sqrt(mu/rad);
	double ang = diff.getAngle();
	ang += M_PI/4;
	Vector2D thrust = Vector2D(ang)*v;
	ship->incVel(thrust);
}

void Gravity::update(int delta) {
	if (paused) { //only update menu when paused
		menu->update(delta);
		return;
	}
	int loopDelta = 10;
	int cdelta = delta;
	while(cdelta > 0) {
		cdelta -= loopDelta;
		
		//rotate ship, and handle thrust
		if (k->check("left")) ship->incHeading(-pps(3,loopDelta));
		if (k->check("right")) ship->incHeading(pps(3,loopDelta));
		if (k->check("up")) {
			ship->thrust(loopDelta);
		}

		if (k->check("fire")) {
			//generate a projectile from the ship
			Projectile * p = ship->fire(0);
			if (p != NULL) {
				projectiles.push_back(p);
			}
		}
		
		if (k->check("reset")) {
			ship->set(-50,200);
			ship->setVel(0,0);		
		}
		
		// camera controls
		int panSpeed = 300;
		if (k->check("pan_up")) v->incY(-pps(panSpeed,loopDelta));
		if (k->check("pan_down")) v->incY(pps(panSpeed,loopDelta));
		if (k->check("pan_left")) v->incX(-pps(panSpeed,loopDelta));
		if (k->check("pan_right")) v->incX(pps(panSpeed,loopDelta));
		// if this line is uncommented, the camera follows the ship
		//v->set(ship->getX(), ship->getY());

		//handle collisions with planets both the ship and the enemies
		//also updates the planet's gravitational field on the ship
		for (int i=0; i<planets.size(); i++) {
			if (planets[i]->distanceTo(ship) < planets[i]->getRadius()) {
				ship->set(-50,200);
				ship->setVel(0,0);
			}
			planets[i]->affect(ship,loopDelta); //add the gravitational pull of the planet
			for (int l=0; l < enemies.size(); l++) {
				planets[i]->affect(enemies[l],loopDelta); //gravity of planet
				if (planets[i]->distanceTo(enemies[l]) < planets[i]->getRadius()) {
					enemies[l]->kill();
				}
			}
		}

		
		for (int i=0; i<projectiles.size(); i++) {
			// saved temporarily, code makes the projectiles follow the mouse
/*			Projectile * proj = projectiles[i];
			Vector2D target = v->getMouse();
			target -= Vector2D(*proj);
			double bearing = target.getAngle();
			double angleDiff = angleTo(proj->getHeading(),bearing);
			if (fabs(angleDiff) > M_PI/100) {
				double turnSpeed = pps(M_PI,loopDelta);
				double turn = fmin(fabs(angleDiff),turnSpeed);
				if (angleDiff > 0) {
					proj->incHeading(-turn);
				} else {
					proj->incHeading(turn);						
				}
			}
			proj->setVel(Vector2D(proj->getHeading())*300);*/
		
			//handle projectile collisions with the planets	and update gravity on projectiles
			//note, some projectiles have no mass, so some are unaffected
			for (int l=0; l<planets.size(); l++) {
				if (planets[l]->distanceTo(projectiles[i]) < planets[l]->getRadius()) {
					projectiles[i]->setLife(0);
				}
				planets[l]->affect(projectiles[i],loopDelta);
			}

			for (int l=0; l < enemies.size(); l++) {
				Vector2D diff = *projectiles[i] - *enemies[l];
				//DESTROY enemy ship
				if (diff.getMagnitude() < 7) {
					// spawn 200 particle debries with random directions, size and lives
					for (int j=0; j<200; j++) {
						int angle = random()%360;
						int mag = random()%50;
						int size = random()%30;
						Particle * p = new Particle(10000+random()%100000); //duration
						p->setX(enemies[l]->getX());
						p->setY(enemies[l]->getY());
						Vector2D vel(M_PI*(angle/180.0));
						vel *= mag;
						vel += enemies[l]->getVel();
						p->setVel(vel.getX(),vel.getY());
						p->setMass(size/10.0);
						particles.push_back(p);
					}
					projectiles[i]->kill(); //sets them to be purged
					enemies[l]->kill();
				}
			}
			
			//update particles and remove if necessary	
			projectiles[i]->update(loopDelta);
			if (projectiles[i]->isDead()) {
				delete projectiles[i];
				projectiles.erase(projectiles.begin()+i);
				i--;
			}
		}

		//update particles
		for (int i=0; i < particles.size(); i++) {
			// handle particle collisions and gravities based on planets	
			for (int l=0; l < planets.size(); l++) {
				planets[l]->affect(particles[i],loopDelta);
				if (planets[l]->distanceTo(particles[i]) < planets[l]->getRadius()) {
					particles[i]->kill();
				}
			}
			//remove dead particles
			particles[i]->update(loopDelta);
			if (particles[i]->isDead()) {
				delete particles[i];
				particles.erase(particles.begin()+i);
				i--;
			}
		}

		// update enemy ship positions	
		for (int i=0; i < enemies.size(); i++) {
			if (enemies[i]->isDead()) {
				delete enemies[i];
				enemies.erase(enemies.begin()+i);
				i--;
				continue;
			}
			enemies[i]->update(loopDelta);
			
			// ENEMY SHIP planet avoidance AI
			int lookAhead = 2000;
			int cLook = 0;
			bool collide = false;
			int collidedPlanet = -1;
			Inertial * ghost = new Inertial(*enemies[i]);
			int loopDelta = 10;
			//we trace forward along our calculated path at our current velocity
			while(cLook < lookAhead) {
				cLook += loopDelta;
				float color = (float)(lookAhead-cLook)/lookAhead;
				glColor3f(color,0.0,color);
				gvi(ghost->getX(), ghost->getY());
				for (int l=0; l<planets.size(); l++) {
					planets[l]->affect(ghost,loopDelta);
					if (planets[l]->distanceTo(ghost) < planets[l]->getRadius()) {
						collide = true;
						collidedPlanet = l;
						break;
					}
				}
				// if theres a collision we'll try to avoid it
				if (collide) break;
				ghost->updatePos(loopDelta);
				//update the ghost's position
			}
			delete ghost;
			if (collide) {
				// on collision, we accelerate in a direction perpendicular to
				// the direction to the planet that we're about to collide with
				// we consider which perpendicular to take based on our current velocity
				Vector2D diff = *enemies[i] - planets[collidedPlanet]->getPos();
				double ang = diff.getAngle();
				double left = ang + M_PI/4;
				double right = ang - M_PI/4;
				double velAng = enemies[i]->getVel().getAngle();
				double thrustDirection = 0;
				if (fabs(left-velAng) > fabs(right-velAng)) {
					thrustDirection = right;
				} else {
					thrustDirection = left;
				}
				enemies[i]->setHeading(thrustDirection);
				enemies[i]->thrust(loopDelta);
			}
			//we align ourself to our velocity after thrusting
			enemies[i]->setHeading(enemies[i]->getVel().getAngle());
		}
		ship->update(loopDelta);
		v->update(loopDelta);
	}
}

//draw our game
void Gravity::draw() {
	glPushMatrix();
	v->apply();
	
	Color(255,255,255).set();
	glBegin(GL_POLYGON);
	Vector2D mouse = v->getMouse();
	dot(mouse.getX(), mouse.getY(), 7);
	glEnd();

//commented code is graphical debugging
/*	glBegin(GL_LINES);
	for(int i=0; i<projectiles.size(); i++) {
		gvi(projectiles[i]->getX(),projectiles[i]->getY());
		Vector2D target = v->getMouse();
		target -= Vector2D(*projectiles[i]);
		target = target.getUnitVector()*10 + Vector2D(projectiles[i]->getX(), projectiles[i]->getY());
		gvi(target);
	}
	glEnd();*/
	
	//for (int i=0; i<projectiles.size(); i++) {
	//	drawPrediction(projectiles[i]);
	//}

	//draws the predicted path of the ship at the current velocity and heading
	drawPrediction(ship);
	
	glColor3f(1.0,1.0,1.0);
	
	for(int i=0; i<enemies.size(); i++) {
		enemies[i]->draw();
	}
	
	for(int i=0; i<particles.size(); i++) {
		particles[i]->draw();
	}
	
	ship->draw();
	for (int i=0; i<planets.size(); i++) {
		planets[i]->draw();
	}
	
	for (int i=0; i<projectiles.size(); i++) {

//	projectile graphical debugging

//		double heading = projectiles[i]->getHeading();
//		double dist = 800;
//		double cone = M_PI/6;
/*		Color(255,255,255).set();
		Vector2D ppos = Vector2D(projectiles[i]->getX(),projectiles[i]->getY());
		Vector2D left = ppos + Vector2D(heading-cone)*dist;
		Vector2D right = ppos + Vector2D(heading+cone)*dist;
		glBegin(GL_LINE_LOOP);
		gvi(left);
		gvi(right);
		gvi(ppos);
		glEnd();
		
		Vector2D ind = ppos + Vector2D(projectiles[i]->angto)*100;
		glBegin(GL_LINES);
		gvi(ind);
		gvi(ppos);
		glEnd();
		
		glBegin(GL_LINE_LOOP);
		circle(projectiles[i]->getX(),projectiles[i]->getY(),projectiles[i]->enemyDist);
		glEnd();
		
		Color(0,0,255).set();
		glBegin(GL_POLYGON);
		dot(projectiles[i]->cx,projectiles[i]->cy,5);
		glEnd();*/
		
		projectiles[i]->draw();		
	}

	glPopMatrix();
	
	//gui
	glPushMatrix();
	v->applyGUI();
	
	if (paused) menu->draw();
	
	glBegin(GL_POLYGON);
	glEnd();
	Ship * monitor = ship;
	// draws the heat and energy bars in the top left corner
	if (monitor) {
		int mx = 0;
		int my = 120;
		Color heat = Color(221,57,217);
		Color overHeat = Color(255,0,0);
		makeBar(mx+10,my+10,10,50,monitor->getEnergy(),monitor->getCapacitor()->getCapacity(),false, Color(50,50,50), Color(0,0,255));
		
		Color use = heat;
		if (ship->isThrusterOverheating()) use = overHeat;
		makeBar(mx+30,my+10,10,50,monitor->getThrusterHeat(),monitor->getThruster()->getHeatCapacity(),false, Color(50,50,50), use);
		use = heat;
		if (ship->isGeneratorOverheating()) use = overHeat;
		makeBar(mx+50,my+10,10,50,monitor->getGeneratorHeat(),monitor->getGenerator()->getHeatCapacity(),false, Color(50,50,50), use);
		use = Color(150,150,255);
		makeBar(mx+70,my+10,10,50,monitor->getFlashCooling(),monitor->getRadiator()->getFlashCoolingCapacity(),false, Color(50,50,50), use);
	}
	//end gui
	glPopMatrix();
}

void Gravity::mouseMoved(SDL_Event event) {
	v->setMouse(event.motion.x, event.motion.y);
}

void Gravity::mouseButton(SDL_Event event) {
//	k->handleMouseEvent(event);
}

void Gravity::keyDown(SDL_Event event) {
	k->handleKeyEvent(event);
	if (k->check("zoom_in",event)) v->zoomIn();
	if (k->check("zoom_out",event)) v->zoomOut();
	if (k->check("pause",event)) paused = !paused;
	
	// use the pan keys for navigating menu
	// to be changed ,they should have their own bindings
	if (paused) {
		if (k->check("pan_left",event)) menu->left();
		if (k->check("pan_right",event)) menu->right();
		if (k->check("pan_up",event)) menu->up();
		if (k->check("pan_down",event)) menu->down();
		if (k->check("menu_select",event)) menu->equipSelected();
	}

	//toggle full screen mode
	if (event.key.keysym.sym == SDLK_f && (event.key.keysym.mod & KMOD_LMETA || event.key.keysym.mod & KMOD_RMETA)) {
		fullscreen = !fullscreen;
		if (fullscreen) {
			const SDL_VideoInfo * vi = SDL_GetVideoInfo();
			
			int resx = vi->current_w;
			int resy = vi->current_h;
			SDL_SetVideoMode(resx, resy, 0, SDL_OPENGL | SDL_FULLSCREEN);
		} else {
			SDL_SetVideoMode(1024, 640, 0, SDL_OPENGL);
		}
	}
}

void Gravity::keyUp(SDL_Event event) {
	k->handleKeyEvent(event);
}

//this draws a predicted path of the given inertial object
// it takes into consideration the current velocity and of course the positions of the planets
void Gravity::drawPrediction(Inertial * target) {
	glBegin(GL_LINES);
	int lookAhead = 20000; //distance to draw
	int cLook = 0;
	bool collide = false;
	Inertial * ghost = new Inertial(*target);
	int loopDelta = 10;
	while(cLook < lookAhead) {
		cLook += loopDelta;
		float color = (float)(lookAhead-cLook)/lookAhead; //color based on distance
		glColor3f(color,0.0,color);
		gvi(ghost->getX(), ghost->getY()); //plot point
		// loop through planets and affect the ghost
		for (int l=0; l<planets.size(); l++) {
			planets[l]->affect(ghost,loopDelta);
			if (planets[l]->distanceTo(ghost) < planets[l]->getRadius()) {
				collide = true;
				break;
			}
		}
		if (collide) break;
		ghost->updatePos(loopDelta);
		gvi(ghost->getX(),ghost->getY());
		// this code breaks out if we get too close to our initial position
		// in the case of a near perfect ellipse, this makes it so that we dont draw over our
		// old lines
		double dAngle = ghost->getVel().getAngle() - ship->getVel().getAngle();
		if (ghost->distanceTo(ship) < 3 && fabs(dAngle) < M_PI/48 && cLook > lookAhead/10 ) break;
	}
	delete ghost;
	glEnd();
}
