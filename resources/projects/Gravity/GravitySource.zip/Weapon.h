/*
 *  Weapon.h
 *  Gravity
 *
 *  Created by Julian on 10/19/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

#ifndef Weapon_H
#define Weapon_H

#include "Part.h"

class Weapon : public Part {
	double reloadTime;
	double firingRate; //shots per minute
	double usageDrain;
	double usageHeat;
	double heatCapacity;
	double coolingRate;
	
	double capacity;
	
	int ammunitionType;
	double ammunitionMass;
	double muzzleVelocity;
	
public:
	Weapon(double reloadTime, double firingRate, double usageDrain, double usageHeat, double heatCapacity, double coolingRate, double capacity, int ammunitionType, double ammunitionMass, double muzzleVelocity, double mass);
	
	std::vector<Attribute> getAttributes();
	
	double getReloadTime();
	void setReloadTime(double reloadTime);
	double getFiringRate();
	void setFiringRate(double firingRate);
	double getUsageDrain();
	void setUsageDrain(double usageDrain);
	double getUsageHeat();
	void setUsageHeat(double usageHeat);
	double getHeatCapacity();
	void setHeatCapacity(double heatCapacity);
	double getCoolingRate();
	void setCoolingRate(double coolingRate);
	double getCapacity();
	void setCapacity(double capacity);
	int getAmmunitionType();
	void setAmmunitionType(int ammunitionType);
	double getAmmunitionMass();
	void setAmmunitionMass(double ammunitionMass);
	double getMuzzleVelocity();
	void setMuzzleVelocity(double muzzleVelocity);
};
#endif