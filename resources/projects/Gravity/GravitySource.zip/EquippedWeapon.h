/*
 *  EquippedWeapon.h
 *  Gravity
 *
 *  Created by Julian on 10/19/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

#ifndef EquippedWeapon_H
#define EquippedWeapon_H

#include "Weapon.h"
#include "Functions.h"

class EquippedWeapon {
	Weapon * w;
	double ammo;
	double heat;
	double shotDelay;
	
	bool overheat;
public:
	EquippedWeapon(Weapon * w);
	
	Weapon * getWeapon();
	
	bool canFire();
	void fire();
	void update(int delta);
	
	double getAmmo();
	void setAmmo(double ammo);
	void incAmmo(double ammo);
	double getHeat();
	void setHeat(double heat);
	void incHeat(double heat);
	double getShotDelay();
	void setShotDelay(double shotDelay);
	void incShotDelay(double shotDelay);
};

#endif