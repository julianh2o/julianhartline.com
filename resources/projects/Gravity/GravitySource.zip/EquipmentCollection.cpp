/*
 *  EquipmentCollection.cpp
 *  Gravity
 *
 *  Created by Julian on 8/25/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// this class is a collection of equipment. It contains a set of part objects
// for each equipment type.
// This is used to maintain a set of parts that can be browsed through based
// on type.

#include "EquipmentCollection.h"

// parts are stored in a vector of vectors.
// the first vector has a static size, the number of part types
// the inner vector grows as it is needed to when parts are added.
EquipmentCollection::EquipmentCollection() {
	for (int i=0; i<NUM_PART_TYPES; i++) {
		parts.push_back(NULL);
	}
}

EquipmentCollection::~EquipmentCollection() {
	
}

void EquipmentCollection::setPartSet(PartType type, PartSet * partset) {
	parts[type] = partset;
}

int EquipmentCollection::getPartCount(PartType type) {
	return parts[type]->getSize();
}

int EquipmentCollection::getTypeCount() {
	return NUM_PART_TYPES;
}

Part* EquipmentCollection::getPart(PartType type, int partId) {
	return parts[type]->getPartAt(partId);
}
