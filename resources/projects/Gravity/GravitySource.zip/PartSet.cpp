/*
 *  PartSet.cpp
 *  Gravity
 *
 *  Created by Julian on 8/26/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// a part set is a group of parts of the same type
// this is used for creating a list of parts for the user
// to equip

#include "PartSet.h"

PartSet::PartSet() {
	
}

void PartSet::addPart(Part * part) {
	parts.push_back(part);
}

int PartSet::getSize() {
	return parts.size();
}

Part * PartSet::getPartAt(int index) {
	return parts[index];
}
