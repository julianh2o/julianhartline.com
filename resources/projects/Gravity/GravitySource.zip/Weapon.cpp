/*
 *  Weapon.cpp
 *  Gravity
 *
 *  Created by Julian on 10/19/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// holds the specifications for a weapon

#include "Weapon.h"

Weapon::Weapon(double reloadTime, double firingRate, double usageDrain, double usageHeat, double heatCapacity, double coolingRate, double capacity, int ammunitionType, double ammunitionMass, double muzzleVelocity, double mass) : Part(mass) {
	this->reloadTime = reloadTime;
	this->firingRate = firingRate;
	this->usageDrain = usageDrain;
	this->usageHeat = usageHeat;
	this->heatCapacity = heatCapacity;
	this->coolingRate = coolingRate;
	this->capacity = capacity;
	this->ammunitionType = ammunitionType;
	this->ammunitionMass = ammunitionMass;
	this->muzzleVelocity = muzzleVelocity;
}

std::vector<Attribute> Weapon::getAttributes() {
	std::vector<Attribute> attr = std::vector<Attribute>();
	attr.push_back(Attribute("Mass",getMass()));
	attr.push_back(Attribute("Reload Time",reloadTime));
	attr.push_back(Attribute("Firing Rate",firingRate));
	attr.push_back(Attribute("Usage Drain",usageDrain));
	attr.push_back(Attribute("Usage Heat",usageHeat));
	attr.push_back(Attribute("Heat Capacity",heatCapacity));
	attr.push_back(Attribute("Cooling Rate",coolingRate));
	attr.push_back(Attribute("Capacity",capacity));
	attr.push_back(Attribute("Ammunition Type",ammunitionType));
	attr.push_back(Attribute("Ammunition Mass",ammunitionMass));
	attr.push_back(Attribute("Muzzle Velocity",muzzleVelocity));
	return attr;	
}

double Weapon::getReloadTime() {
	return reloadTime;
}

void Weapon::setReloadTime(double reloadTime) {
	this->reloadTime = reloadTime;
}

double Weapon::getFiringRate() {
	return firingRate;
}

void Weapon::setFiringRate(double firingRate) {
	this->firingRate = firingRate;
}

double Weapon::getUsageDrain() {
	return usageDrain;
}

void Weapon::setUsageDrain(double usageDrain) {
	this->usageDrain = usageDrain;
}

double Weapon::getUsageHeat() {
	return usageHeat;
}

void Weapon::setUsageHeat(double usageHeat) {
	this->usageHeat = usageHeat;
}

double Weapon::getHeatCapacity() {
	return heatCapacity;
}

void Weapon::setHeatCapacity(double heatCapacity) {
	this->heatCapacity = heatCapacity;
}

double Weapon::getCoolingRate() {
	return coolingRate;
}

void Weapon::setCoolingRate(double coolingRate) {
	this->coolingRate = coolingRate;
}

double Weapon::getCapacity() {
	return capacity;
}

void Weapon::setCapacity(double capacity) {
	this->capacity = capacity;
}

int Weapon::getAmmunitionType() {
	return ammunitionType;
}

void Weapon::setAmmunitionType(int ammunitionType) {
	this->ammunitionType = ammunitionType;
}

double Weapon::getAmmunitionMass() {
	return ammunitionMass;
}

void Weapon::setAmmunitionMass(double ammunitionMass) {
	this->ammunitionMass = ammunitionMass;
}

double Weapon::getMuzzleVelocity() {
	return muzzleVelocity;
}

void Weapon::setMuzzleVelocity(double muzzleVelocity) {
	this->muzzleVelocity = muzzleVelocity;
}	
