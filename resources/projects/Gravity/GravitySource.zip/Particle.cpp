/*
 *  Particle.cpp
 *  Gravity
 *
 *  Created by Julian on 9/15/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// a particle is an inertial object that displays as simply a dot of
// various sizes
// it has a life span

#include "Particle.h"

Particle::Particle(int life) {
	this->life = life;
	dead = false;
}

void Particle::draw() {
	glBegin(GL_POLYGON);
	int size = (int)getMass();
	if (size < 2) size = 2;
	rect(getX(),getY(),getX()+size,getY()+size);
	glEnd();
}

void Particle::update(int delta) {
	life -= delta;
	if (life <= 0) kill();
	updatePos(delta);
}

bool Particle::isDead() {
	return dead;
}

void Particle::kill() {
	dead = true;
}
