/*
 *  EquipMenu.cpp
 *  Gravity
 *
 *  Created by Julian on 8/24/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// this class handles the creation and display of a menu displaying equipment
// within an equimpent collection
// this class also handles the equipping of parts to the ship when space is pressed

#include "EquipMenu.h"

// some constants, to be relocated
int centerx = 400;
int centery = 400;
int width = 160;
int spacingx = 2;
int height = 160;
int spacingy = 20;

EquipMenu::EquipMenu(EquipmentCollection * eq, Ship * ship) {
	this->eq = eq;
	this->ship = ship;
	// this is the target position of each part "reel". The values in this are change
	// when the user presses the left and right arrow to change their selection
	// as the menu updates, offsetX changes to match the targetX in a smooth animation
	targetX = std::vector<int>(); 
	offsetX = std::vector<double>();
	for (int y=0; y<eq->getTypeCount(); y++) {
		for (int x=0; x<eq->getPartCount((EquipmentCollection::PartType)y); x++) {
			// checks to see if the part is currently equipped
			if (eq->getPart((EquipmentCollection::PartType)y,x) == ship->getPart((EquipmentCollection::PartType)y)) {
 				//if the part is equipped, default to having it shown
				targetX.push_back(x);
				break;
			}
		}
		offsetX.push_back(0);
	}
	// handles the animation along the Y axis
	targetY = 0;
	offsetY = 0;
	//update with a high delta to make sure all of our offsets are correct
	update(3000);
}

void EquipMenu::draw() {
	//loop through the parts
	for (int y=0; y<eq->getTypeCount(); y++) {
		for (int x=0; x<eq->getPartCount((EquipmentCollection::PartType)y); x++) {
			// calculate the current position based on the animation offsets
			int topleftX = - offsetX[y] + centerx - width/2 + (width + spacingx)*(x);
			int topleftY = - offsetY + centery - height/2 + (height + spacingy)*(y);
			//calculate the distance from the center so we can fade further panels
			double mag = dist(centerx, centery, topleftX+width/2, topleftY+height/2);
			//if the panel is too far away, we dont display it
			if (mag < 255) {
				//set the color of the potentially fading panel
				int c = (255-mag*.75);
				Color(c,c,c).set();
				if (eq->getPart((EquipmentCollection::PartType)y,x) == ship->getPart((EquipmentCollection::PartType)y)) {
					// part is equipped, adjust color
					Color(c/2,c/2,c).set();	
				}
				//draw the panel
				glBegin(GL_LINE_LOOP);
				rect(topleftX,topleftY,topleftX+width,topleftY+height);
				glEnd();
				Color(c,c,c).set();
				// display the attribute text
				//TODO make sure that text doesnt run over xbounds/ybounds
				std::vector<Attribute> attribs = eq->getPart((EquipmentCollection::PartType)y,x)->getAttributes();
				for (int i=0; i<attribs.size(); i++) {
					drawText(topleftX+5,topleftY+14+20*i,attribs[i].getString(),GLUT_BITMAP_HELVETICA_10);
				}
			}
		}
	}
}

//updates the animation of the menu
void EquipMenu::update(int delta) {
	double speed = 700; //to be relocated
	for (int i=0; i<eq->getTypeCount(); i++) {
		//the offset position that the current selection suggests that we have
		int targetOffsetX = targetX[i]*(width + spacingx);
		// update the offset, and check for overshooting target
		if (offsetX[i] < targetOffsetX) {
			offsetX[i] += pps(speed,delta);
			if (offsetX[i] > targetOffsetX) offsetX[i] = targetOffsetX;
		} else {
			offsetX[i] -= pps(speed,delta);
			if (offsetX[i] < targetOffsetX) offsetX[i] = targetOffsetX;		
		}
	}
	//animate Yoffset
	int targetOffsetY = targetY*(height + spacingy);
	if (offsetY < targetOffsetY) {
		offsetY += pps(speed,delta);
		if (offsetY > targetOffsetY) offsetY = targetOffsetY;
	} else {
		offsetY -= pps(speed,delta);
		if (offsetY < targetOffsetY) offsetY = targetOffsetY;
	}
}

// These are called by the keyboard handler to let the user manipulate the menu
// simply changes the target, all else is handled in the update
void EquipMenu::left() {
	targetX[targetY]--;
	if (targetX[targetY] < 0) targetX[targetY] = 0;
}

void EquipMenu::right() {
	int partcount = eq->getPartCount((EquipmentCollection::PartType)targetY);
	targetX[targetY]++;

	if (targetX[targetY] > partcount-1) targetX[targetY] = partcount-1;
}

void EquipMenu::up() {
	targetY--;
	if (targetY < 0) targetY = 0;
}

void EquipMenu::down() {
	targetY++;
	if (targetY > eq->getTypeCount()-1) targetY = eq->getTypeCount()-1;
}

// equip the selected piece to the given ship
void EquipMenu::equipSelected() {
	ship->equip(eq->getPart((EquipmentCollection::PartType)targetY,targetX[targetY]));
}
