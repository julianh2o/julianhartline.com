/*
 *  Constants.h
 *  Gravity
 *
 *  Created by Julian on 8/19/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

#ifndef Constants_H
#define Constants_H

const int GRAV_G = 50000;

#endif
