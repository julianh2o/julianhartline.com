/*
 *  EquippedWeapon.cpp
 *  Gravity
 *
 *  Created by Julian on 10/19/09.
 *  Copyright 2009 Julian Hartline. All rights reserved.
 *
 */

// this class represents a weapon equipped to a ship
// it is used to keep track of instance specific weapon information

#include "EquippedWeapon.h"

EquippedWeapon::EquippedWeapon(Weapon * w) {
	this->w = w;
	overheat = false;
	shotDelay = 0;
	ammo = 100; //to be relocated
}

Weapon * EquippedWeapon::getWeapon() {
	return w;
}

// determines if the weapon can be fired based on the ammo, overheat and last shot
bool EquippedWeapon::canFire() {
	return ammo > 0 && !overheat && shotDelay <= 0;
}

void EquippedWeapon::fire() {
	double spm = w->getFiringRate(); //shots per minute
	shotDelay = 1000/(spm/60);
	incHeat(w->getUsageHeat());
	ammo--;
}

// slowly cools the weapon and decrements the shotdelay
void EquippedWeapon::update(int delta) {
	incHeat(-pps(w->getCoolingRate(),delta));
	incShotDelay(-delta);
}

double EquippedWeapon::getAmmo() {
	return ammo;
}

void EquippedWeapon::setAmmo(double ammo) {
	ammo = bound(ammo,0.0,w->getCapacity());
	this->ammo = ammo;
}

void EquippedWeapon::incAmmo(double ammo) {
	setAmmo(getAmmo() + ammo);
}

double EquippedWeapon::getHeat() {
	return heat;
}

void EquippedWeapon::setHeat(double heat) {
	if (heat <= 0) {
		heat = 0;
		overheat = false;
	}

	if (heat >= w->getHeatCapacity()) {
		heat = w->getHeatCapacity();
		overheat = true;
	}
	this->heat = heat;
}

void EquippedWeapon::incHeat(double heat) {
	setHeat(getHeat()+heat);
}

double EquippedWeapon::getShotDelay() {
	return shotDelay;
}

void EquippedWeapon::setShotDelay(double shotDelay) {
	if (shotDelay < 0) shotDelay = 0;
	this->shotDelay = shotDelay;
}

void EquippedWeapon::incShotDelay(double shotDelay) {
	setShotDelay(getShotDelay() + shotDelay);
}
